import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';

export default function Apresentacao() {
  return (
    <View style={styles.container}>
      <Image 
        source={{ uri: 'https://gartic.com.br/imgs/mural/ri/rickmortyn_/zabuza-momochi.png' }}
        style={styles.foto} 
      />
      <Text style={styles.nome}>Gabriel</Text>
      <Text style={styles.info}>17 anos | Estudante na ETEC</Text>
      <Text style={styles.descricao}>
        Quero virar programador, mas ainda não tenho uma área de escolha definida.
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f4f8',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 30,
  },
  foto: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 25,
    borderWidth: 3,
    borderColor: '#4a90e2',
  },
  nome: {
    fontSize: 32,
    fontWeight: '700',
    color: '#333',
    marginBottom: 8,
  },
  info: {
    fontSize: 18,
    color: '#333',
    marginBottom: 20,
    
  },
  descricao: {
    fontSize: 16,
    color: '#333',
    textAlign: 'center',
    lineHeight: 24,
  },
});