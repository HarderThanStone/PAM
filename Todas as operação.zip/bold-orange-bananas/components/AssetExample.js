import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

export default function App() {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [resultado, setResultado] = useState(null);

  const calcular = (operacao) => {
    const n1 = parseFloat(num1);
    const n2 = parseFloat(num2);

    if (isNaN(n1) || isNaN(n2)) {
      setResultado('Digite dois números válidos');
      return;
    }

    let res = 0;
    switch (operacao) {
      case '+':
        res = n1 + n2;
        break;
      case '-':
        res = n1 - n2;
        break;
      case '*':
        res = n1 * n2;
        break;
      case '/':
        if (n2 === 0) {
          setResultado('Não é possível dividir por zero');
          return;
        }
        res = n1 / n2;
        break;
      default:
        return;
    }

    setResultado(res);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Calculadora Básica</Text>
      <TextInput
        style={styles.input}
        placeholder="Número 1"
        keyboardType="numeric"
        value={num1}
        onChangeText={setNum1}
      />
      <TextInput
        style={styles.input}
        placeholder="Número 2"
        keyboardType="numeric"
        value={num2}
        onChangeText={setNum2}
      />

      <View style={styles.buttons}>
        <Button title="+" onPress={() => calcular('+')} />
        <Button title="−" onPress={() => calcular('-')} />
        <Button title="×" onPress={() => calcular('*')} />
        <Button title="÷" onPress={() => calcular('/')} />
      </View>

      <Text style={styles.result}>
        Resultado: {resultado !== null ? resultado : '—'}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
  input: {
    width: '80%',
    borderColor: '#888',
    borderWidth: 1,
    padding: 8,
    marginVertical: 8,
    borderRadius: 4,
  },
  buttons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '80%',
    marginVertical: 16,
  },
  result: {
    fontSize: 20,
    marginTop: 20,
  },
});
